'use client'

import { Database, HeartPulse, LoaderCircle, Phone, Wifi } from 'lucide-react'
import { useApp } from './app-context'
import { LANGS } from '@/lib/i18n'
import { cn } from '@/lib/utils'

export function EmergencyBar() {
  const { t, lang, setLang, online, syncing } = useApp()

  return (
    <header className="flex flex-col gap-3 border-b border-border bg-background px-4 pb-3 pt-4">
      <div className="flex items-center gap-3">
        <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <HeartPulse className="size-7" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-xl font-black leading-tight">{t.appName}</p>
          <p className="truncate text-sm text-muted-foreground">{t.tagline}</p>
        </div>
        <a
          href="tel:108"
          aria-label={t.call108}
          className="flex min-h-12 items-center gap-2 rounded-xl bg-primary px-4 text-lg font-black text-primary-foreground"
        >
          <Phone className="size-5 fill-current" aria-hidden />
          108
        </a>
      </div>

      <div
        role="status"
        className={cn(
          'flex min-h-11 items-center gap-2.5 rounded-xl border-2 px-3 text-base font-bold',
          online ? 'border-success bg-success/10 text-success' : 'border-warning bg-warning/10 text-warning',
        )}
      >
        <span className="relative flex size-3 shrink-0" aria-hidden>
          <span className={cn('absolute inline-flex size-full animate-ping rounded-full opacity-60', online ? 'bg-success' : 'bg-warning')} />
          <span className={cn('relative inline-flex size-3 rounded-full', online ? 'bg-success' : 'bg-warning')} />
        </span>
        <span className="flex-1 leading-tight">{online ? t.online : t.offline}</span>
        {online ? (
          syncing ? <LoaderCircle className="size-5 animate-spin" aria-hidden /> : <Wifi className="size-5" aria-hidden />
        ) : (
          <Database className="size-5" aria-hidden />
        )}
      </div>

      <div role="radiogroup" aria-label={t.language} className="grid grid-cols-4 gap-1.5 rounded-xl bg-card p-1">
        {LANGS.map((l) => (
          <button
            key={l.code}
            type="button"
            role="radio"
            aria-checked={lang === l.code}
            aria-label={l.name}
            lang={l.code}
            onClick={() => setLang(l.code)}
            className={cn(
              'min-h-12 rounded-lg text-lg font-bold transition-colors',
              lang === l.code ? 'bg-foreground text-background' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {l.label}
          </button>
        ))}
      </div>
    </header>
  )
}
