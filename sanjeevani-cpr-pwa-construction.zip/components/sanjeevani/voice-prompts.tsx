'use client'

import { Volume2 } from 'lucide-react'
import { useApp } from './app-context'

export type PromptKey = 'promptHard' | 'promptRecoil' | 'promptCenter' | 'promptDontStop'

const PROMPTS: PromptKey[] = ['promptHard', 'promptRecoil', 'promptCenter', 'promptDontStop']

export function VoicePrompts({ onPlay }: { onPlay: (key: PromptKey) => void }) {
  const { t } = useApp()
  return (
    <section aria-labelledby="voice-title" className="rounded-2xl bg-card p-4">
      <h2 id="voice-title" className="text-xl font-bold">
        {t.voiceTitle}
      </h2>
      <p className="text-base text-muted-foreground">{t.voiceHint}</p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {PROMPTS.map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => onPlay(key)}
            className="flex min-h-16 items-center gap-3 rounded-xl border-2 border-border bg-background px-3 text-left text-base font-semibold leading-tight active:border-warning active:text-warning"
          >
            <Volume2 className="size-6 shrink-0 text-warning" aria-hidden />
            {t[key]}
          </button>
        ))}
      </div>
    </section>
  )
}
