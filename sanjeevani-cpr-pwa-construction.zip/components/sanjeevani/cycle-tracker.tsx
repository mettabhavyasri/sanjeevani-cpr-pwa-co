import { cn } from '@/lib/utils'

interface CycleTrackerProps {
  mode: '30:2' | 'continuous'
  cycleCount: number
  total: number
  rounds: number
  elapsed: string
  cycleSize: number
  labels: { compressions: string; cycles: string; time: string }
}

export function CycleTracker({ mode, cycleCount, total, rounds, elapsed, cycleSize, labels }: CycleTrackerProps) {
  const inCycle = mode === '30:2' ? cycleCount : total % cycleSize

  return (
    <section aria-label={labels.compressions} className="rounded-2xl bg-card p-4">
      <div className="grid grid-cols-3 divide-x divide-border text-center">
        <Stat value={mode === '30:2' ? `${cycleCount}/${cycleSize}` : String(total)} label={labels.compressions} />
        <Stat value={String(rounds)} label={labels.cycles} />
        <Stat value={elapsed} label={labels.time} />
      </div>
      <div
        className="mt-4 grid gap-1"
        style={{ gridTemplateColumns: `repeat(${cycleSize}, minmax(0, 1fr))` }}
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={cycleSize}
        aria-valuenow={inCycle}
      >
        {Array.from({ length: cycleSize }, (_, i) => (
          <span
            key={i}
            className={cn('h-3 rounded-sm transition-colors', i < inCycle ? 'bg-primary' : 'bg-muted')}
          />
        ))}
      </div>
    </section>
  )
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="flex flex-col gap-0.5 px-2">
      <span className="text-2xl font-black tabular-nums">{value}</span>
      <span className="text-sm font-medium text-muted-foreground">{label}</span>
    </div>
  )
}
