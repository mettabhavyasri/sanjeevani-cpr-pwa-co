'use client'

import { CloudCheck, CloudOff, CloudUpload, Inbox, LoaderCircle, Pill, HeartPulse, WifiOff, Wifi } from 'lucide-react'
import { useApp } from './app-context'
import { cn } from '@/lib/utils'
import type { Incident, SyncStatus } from '@/lib/offline-store'

const SYMPTOM_LABEL = {
  chest: 'symChest',
  sweat: 'symSweat',
  radiate: 'symRadiate',
  breath: 'symBreath',
  unconscious: 'symUnconscious',
} as const

export function Outbox() {
  const { t, incidents, online, goOnline, goOffline, syncing } = useApp()
  const pending = incidents.filter((i) => i.status !== 'synced').length
  const synced = incidents.length - pending
  const progress = incidents.length ? (synced / incidents.length) * 100 : 0

  return (
    <div className="flex flex-col gap-5">
      <header>
        <h1 className="text-2xl font-black">{t.outboxTitle}</h1>
        <p className="text-base text-muted-foreground">{t.storedSafe}</p>
      </header>

      <section className="rounded-2xl bg-card p-4">
        <div className="flex items-center gap-4">
          <span
            className={cn(
              'flex size-14 shrink-0 items-center justify-center rounded-2xl',
              pending ? 'bg-warning/15 text-warning' : 'bg-success/15 text-success',
            )}
          >
            {pending ? <CloudUpload className="size-7" aria-hidden /> : <CloudCheck className="size-7" aria-hidden />}
          </span>
          <p className="flex-1 text-lg font-bold leading-tight" aria-live="polite">
            {pending ? (
              <>
                <span className="text-3xl font-black tabular-nums text-warning">{pending}</span> {t.waiting}
              </>
            ) : incidents.length ? (
              <span className="text-success">{t.allSynced}</span>
            ) : (
              t.empty
            )}
          </p>
        </div>

        {incidents.length > 0 && (
          <div
            className="mt-4 h-3 overflow-hidden rounded-full bg-muted"
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={incidents.length}
            aria-valuenow={synced}
          >
            <div className="h-full rounded-full bg-success transition-[width] duration-500" style={{ width: `${progress}%` }} />
          </div>
        )}

        <div className="mt-4">
          {online ? (
            <button
              type="button"
              onClick={goOffline}
              className="flex min-h-14 w-full items-center justify-center gap-3 rounded-xl border-2 border-border text-lg font-bold"
            >
              <WifiOff className="size-6" aria-hidden />
              {t.goOffline}
            </button>
          ) : (
            <button
              type="button"
              onClick={goOnline}
              className="flex min-h-16 w-full items-center justify-center gap-3 rounded-xl bg-success text-lg font-bold text-success-foreground active:scale-[0.98]"
            >
              <Wifi className="size-6" aria-hidden />
              {t.simulate}
            </button>
          )}
          {syncing && (
            <p className="mt-3 flex items-center justify-center gap-2 text-base font-semibold text-success">
              <LoaderCircle className="size-5 animate-spin" aria-hidden />
              {t.syncing}
            </p>
          )}
        </div>
      </section>

      {incidents.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border-2 border-dashed border-border p-10 text-center">
          <Inbox className="size-12 text-muted-foreground" aria-hidden />
          <p className="text-lg font-bold">{t.empty}</p>
          <p className="text-base text-muted-foreground">{t.emptyHint}</p>
        </div>
      ) : (
        <ul className="flex flex-col gap-3">
          {incidents.map((incident) => (
            <IncidentCard key={incident.id} incident={incident} />
          ))}
        </ul>
      )}
    </div>
  )
}

function IncidentCard({ incident }: { incident: Incident }) {
  const { t, lang } = useApp()
  const created = new Date(incident.createdAt).toLocaleString(lang === 'en' ? 'en-IN' : `${lang}-IN`, {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  })
  const sexLabel = t[incident.sex]

  return (
    <li
      className={cn(
        'rounded-2xl border-2 bg-card p-4 transition-colors duration-500',
        incident.status === 'synced' ? 'border-success/40' : incident.status === 'syncing' ? 'border-success' : 'border-warning/40',
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-xl font-bold">{incident.name}</h3>
          <p className="text-base text-muted-foreground">
            {incident.age} {t.years} · {sexLabel} · <time dateTime={new Date(incident.createdAt).toISOString()}>{created}</time>
          </p>
        </div>
        <StatusChip status={incident.status} />
      </div>

      <dl className="mt-3 flex flex-wrap gap-2 text-sm font-semibold">
        {incident.onsetTime && <Tag label={t.onsetAt} value={incident.onsetTime} />}
        {incident.cprStarted && (
          <Tag icon={<HeartPulse className="size-4 text-primary" aria-hidden />} label={t.cprAt} value={incident.cprStartTime || '✓'} />
        )}
        {incident.aspirinGiven && <Tag icon={<Pill className="size-4 text-warning" aria-hidden />} label={t.aspirinGiven} />}
      </dl>

      {incident.symptoms.length > 0 && (
        <p className="mt-2 text-base text-foreground/90">{incident.symptoms.map((s) => t[SYMPTOM_LABEL[s]]).join(' · ')}</p>
      )}
    </li>
  )
}

function Tag({ label, value, icon }: { label: string; value?: string; icon?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1.5 rounded-lg bg-background px-2.5 py-1.5">
      {icon}
      <dt>{label}</dt>
      {value && <dd className="tabular-nums text-foreground">{value}</dd>}
    </div>
  )
}

function StatusChip({ status }: { status: SyncStatus }) {
  const { t } = useApp()
  const config = {
    pending: { icon: CloudOff, label: t.pending, className: 'bg-warning text-warning-foreground' },
    syncing: { icon: LoaderCircle, label: t.syncing, className: 'bg-success/20 text-success' },
    synced: { icon: CloudCheck, label: t.synced, className: 'bg-success text-success-foreground' },
  }[status]
  const Icon = config.icon
  return (
    <span className={cn('inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-bold', config.className)}>
      <Icon className={cn('size-4', status === 'syncing' && 'animate-spin')} aria-hidden />
      <span className="max-w-28 leading-tight">{config.label}</span>
    </span>
  )
}
