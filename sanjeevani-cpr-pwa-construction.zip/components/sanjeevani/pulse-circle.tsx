import { HeartPulse } from 'lucide-react'
import { cn } from '@/lib/utils'

interface PulseCircleProps {
  beatKey: number
  active: boolean
  count: number
  label: string
  idleLabel: string
  bpmLabel: string
}

export function PulseCircle({ beatKey, active, count, label, idleLabel, bpmLabel }: PulseCircleProps) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative flex size-64 items-center justify-center">
        {active && (
          <span
            key={`ring-${beatKey}`}
            aria-hidden
            className="cpr-ring absolute inset-0 rounded-full border-4 border-primary"
          />
        )}
        <div
          key={active ? `beat-${beatKey}` : 'idle'}
          className={cn(
            'relative flex size-56 flex-col items-center justify-center rounded-full',
            active
              ? 'cpr-beat bg-primary text-primary-foreground shadow-[0_0_80px_-10px] shadow-primary'
              : 'border-4 border-dashed border-primary/60 bg-card text-foreground',
          )}
        >
          {active ? (
            <>
              <span className="text-lg font-bold uppercase tracking-widest">{label}</span>
              <span className="text-7xl font-black tabular-nums leading-none" aria-live="off">
                {count}
              </span>
            </>
          ) : (
            <>
              <HeartPulse className="size-14 text-primary" aria-hidden />
              <span className="mt-2 px-6 text-center text-base font-semibold leading-snug text-balance">
                {idleLabel}
              </span>
            </>
          )}
        </div>
      </div>
      <p className="rounded-full bg-card px-4 py-1.5 text-sm font-semibold text-muted-foreground">
        {bpmLabel}
      </p>
    </div>
  )
}
