'use client'

import Image from 'next/image'
import { ArrowDown, ArrowUpFromLine, Hand } from 'lucide-react'
import { useApp } from './app-context'

export function DepthGuide() {
  const { t } = useApp()
  const steps = [
    { icon: Hand, title: t.place, hint: t.placeHint },
    { icon: ArrowDown, title: t.depth, hint: t.depthHint },
    { icon: ArrowUpFromLine, title: t.recoil, hint: t.recoilHint },
  ]

  return (
    <section aria-labelledby="howto-title" className="overflow-hidden rounded-2xl bg-card">
      <div className="relative aspect-[4/3] w-full">
        <Image
          src="/images/hand-placement.png"
          alt={t.illustrationAlt}
          fill
          sizes="(max-width: 448px) 100vw, 448px"
          className="object-cover"
          priority={false}
        />
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-card to-transparent px-4 pb-3 pt-10">
          <h2 id="howto-title" className="text-xl font-bold">
            {t.howTo}
          </h2>
        </div>
      </div>
      <ol className="flex flex-col gap-1 p-3">
        {steps.map(({ icon: Icon, title, hint }, i) => (
          <li key={title} className="flex items-center gap-4 rounded-xl p-2">
            <span className="flex size-14 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <Icon className="size-7" aria-hidden />
            </span>
            <div className="flex-1">
              <p className="text-lg font-bold leading-tight">
                <span className="sr-only">{i + 1}. </span>
                {title}
              </p>
              <p className="text-base leading-snug text-muted-foreground">{hint}</p>
            </div>
            {i === 1 && <DepthMeter />}
          </li>
        ))}
      </ol>
    </section>
  )
}

function DepthMeter() {
  return (
    <div aria-hidden className="flex h-14 w-6 shrink-0 flex-col justify-between rounded-md border-2 border-border p-0.5">
      <span className="depth-fill w-full rounded-sm bg-warning" />
    </div>
  )
}
