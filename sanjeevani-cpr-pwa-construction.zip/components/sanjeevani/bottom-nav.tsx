'use client'

import { ClipboardPlus, HeartPulse, Inbox, Stethoscope } from 'lucide-react'
import { useApp, type Tab } from './app-context'
import { cn } from '@/lib/utils'

export function BottomNav() {
  const { t, tab, setTab, incidents } = useApp()
  const pending = incidents.filter((i) => i.status !== 'synced').length

  const items: { id: Tab; label: string; icon: typeof HeartPulse }[] = [
    { id: 'cpr', label: t.navCpr, icon: HeartPulse },
    { id: 'triage', label: t.navTriage, icon: Stethoscope },
    { id: 'record', label: t.navRecord, icon: ClipboardPlus },
    { id: 'outbox', label: t.navOutbox, icon: Inbox },
  ]

  return (
    <nav
      aria-label="Main"
      className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur"
    >
      <ul className="mx-auto grid max-w-md grid-cols-4">
        {items.map(({ id, label, icon: Icon }) => {
          const active = tab === id
          return (
            <li key={id}>
              <button
                type="button"
                aria-current={active ? 'page' : undefined}
                onClick={() => {
                  setTab(id)
                  window.scrollTo({ top: 0 })
                }}
                className={cn(
                  'relative flex min-h-16 w-full flex-col items-center justify-center gap-1 px-1 text-sm font-semibold',
                  active ? 'text-primary' : 'text-muted-foreground',
                )}
              >
                {active && <span aria-hidden className="absolute inset-x-4 top-0 h-1 rounded-b-full bg-primary" />}
                <span className="relative">
                  <Icon className="size-7" aria-hidden />
                  {id === 'outbox' && pending > 0 && (
                    <span className="absolute -right-2.5 -top-1.5 flex min-w-5 items-center justify-center rounded-full bg-warning px-1 text-xs font-black text-warning-foreground">
                      {pending}
                      <span className="sr-only"> {t.pending}</span>
                    </span>
                  )}
                </span>
                <span className="truncate leading-tight">{label}</span>
              </button>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
