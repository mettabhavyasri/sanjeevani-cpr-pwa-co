'use client'

import { useEffect, useState } from 'react'
import { Check, HardDrive, Save } from 'lucide-react'
import { useApp } from './app-context'
import { cn } from '@/lib/utils'
import { createId, type Sex, type SymptomKey } from '@/lib/offline-store'

const SYMPTOMS: { key: SymptomKey; label: 'symChest' | 'symSweat' | 'symRadiate' | 'symBreath' | 'symUnconscious' }[] = [
  { key: 'chest', label: 'symChest' },
  { key: 'sweat', label: 'symSweat' },
  { key: 'radiate', label: 'symRadiate' },
  { key: 'breath', label: 'symBreath' },
  { key: 'unconscious', label: 'symUnconscious' },
]

interface FormState {
  name: string
  age: string
  sex: Sex
  onsetTime: string
  symptoms: SymptomKey[]
  aspirinGiven: boolean | null
  cprStarted: boolean | null
  cprStartTime: string
  notes: string
}

const EMPTY: FormState = {
  name: '',
  age: '',
  sex: 'male',
  onsetTime: '',
  symptoms: [],
  aspirinGiven: null,
  cprStarted: null,
  cprStartTime: '',
  notes: '',
}

const inputClass =
  'min-h-14 w-full rounded-xl border-2 border-border bg-background px-4 text-lg text-foreground placeholder:text-muted-foreground focus:border-warning focus:outline-none'

export function IncidentForm() {
  const { t, session, sessionVersion, clearSession, saveIncident, setTab } = useApp()
  const [form, setForm] = useState<FormState>(EMPTY)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const [justSaved, setJustSaved] = useState(false)
  const [prefilled, setPrefilled] = useState(false)

  useEffect(() => {
    if (sessionVersion === 0) return
    setForm((f) => ({
      ...f,
      symptoms: session.symptoms ? Array.from(new Set([...f.symptoms, ...session.symptoms])) : f.symptoms,
      aspirinGiven: session.aspirinGiven ?? f.aspirinGiven,
      cprStarted: session.cprStartTime ? true : f.cprStarted,
      cprStartTime: session.cprStartTime ?? f.cprStartTime,
    }))
    setPrefilled(true)
  }, [sessionVersion, session])

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((f) => ({ ...f, [key]: value }))
    setJustSaved(false)
  }

  const toggleSymptom = (key: SymptomKey) =>
    set('symptoms', form.symptoms.includes(key) ? form.symptoms.filter((s) => s !== key) : [...form.symptoms, key])

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const age = Number.parseInt(form.age, 10)
    if (!form.name.trim() || !Number.isFinite(age) || age < 0 || age > 120) {
      setError(t.required)
      return
    }
    setError('')
    setSaving(true)
    await saveIncident({
      id: createId(),
      name: form.name.trim().slice(0, 80),
      age,
      sex: form.sex,
      onsetTime: form.onsetTime,
      symptoms: form.symptoms,
      aspirinGiven: form.aspirinGiven === true,
      cprStarted: form.cprStarted === true,
      cprStartTime: form.cprStarted ? form.cprStartTime : '',
      notes: form.notes.trim().slice(0, 500),
      createdAt: Date.now(),
      status: 'pending',
    })
    setSaving(false)
    setForm(EMPTY)
    setPrefilled(false)
    clearSession()
    setJustSaved(true)
  }

  return (
    <form onSubmit={onSubmit} noValidate className="flex flex-col gap-5">
      <header>
        <h1 className="text-2xl font-black">{t.newRecord}</h1>
        <p className="flex items-center gap-2 text-base text-muted-foreground">
          <HardDrive className="size-4 shrink-0" aria-hidden />
          {t.recordHint}
        </p>
      </header>

      {justSaved && (
        <div role="status" className="flex items-center gap-3 rounded-2xl border-2 border-success bg-success/10 p-4">
          <Check className="size-7 shrink-0 text-success" aria-hidden />
          <p className="flex-1 text-lg font-bold text-success">{t.saved}</p>
          <button
            type="button"
            onClick={() => setTab('outbox')}
            className="min-h-12 rounded-xl bg-success px-4 text-base font-bold text-success-foreground"
          >
            {t.navOutbox}
          </button>
        </div>
      )}

      {prefilled && !justSaved && (
        <p className="rounded-xl bg-warning/10 px-4 py-3 text-base font-semibold text-warning">{t.prefilled}</p>
      )}

      <fieldset className="flex flex-col gap-4 rounded-2xl bg-card p-4">
        <Field label={t.name} htmlFor="name">
          <input
            id="name"
            className={inputClass}
            value={form.name}
            onChange={(e) => set('name', e.target.value)}
            autoComplete="off"
            maxLength={80}
            required
          />
        </Field>
        <div className="grid grid-cols-[1fr_2fr] gap-3">
          <Field label={t.age} htmlFor="age">
            <input
              id="age"
              className={inputClass}
              inputMode="numeric"
              pattern="[0-9]*"
              value={form.age}
              onChange={(e) => set('age', e.target.value.replace(/\D/g, '').slice(0, 3))}
              required
            />
          </Field>
          <Field label={t.onset} htmlFor="onset">
            <input
              id="onset"
              type="time"
              className={inputClass}
              value={form.onsetTime}
              onChange={(e) => set('onsetTime', e.target.value)}
            />
          </Field>
        </div>
        <div>
          <span className="mb-2 block text-base font-semibold" id="sex-label">
            {t.sex}
          </span>
          <Segmented
            labelledBy="sex-label"
            value={form.sex}
            options={[
              { value: 'male', label: t.male },
              { value: 'female', label: t.female },
              { value: 'other', label: t.other },
            ]}
            onChange={(v) => set('sex', v as Sex)}
          />
        </div>
      </fieldset>

      <fieldset className="rounded-2xl bg-card p-4">
        <legend className="sr-only">{t.symptoms}</legend>
        <p aria-hidden className="mb-3 text-lg font-bold">
          {t.symptoms}
        </p>
        <div className="flex flex-wrap gap-2">
          {SYMPTOMS.map(({ key, label }) => {
            const on = form.symptoms.includes(key)
            return (
              <button
                key={key}
                type="button"
                role="checkbox"
                aria-checked={on}
                onClick={() => toggleSymptom(key)}
                className={cn(
                  'flex min-h-12 items-center gap-2 rounded-full border-2 px-4 text-base font-semibold',
                  on ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-background',
                )}
              >
                {on && <Check className="size-4" aria-hidden />}
                {t[label]}
              </button>
            )
          })}
        </div>
      </fieldset>

      <fieldset className="flex flex-col gap-4 rounded-2xl bg-card p-4">
        <legend className="sr-only">{t.actions}</legend>
        <p aria-hidden className="text-lg font-bold">
          {t.actions}
        </p>
        <YesNo id="aspirin" label={t.aspirinQ} value={form.aspirinGiven} onChange={(v) => set('aspirinGiven', v)} />
        <YesNo id="cpr" label={t.cprQ} value={form.cprStarted} onChange={(v) => set('cprStarted', v)} />
        {form.cprStarted && (
          <Field label={t.cprTime} htmlFor="cprTime">
            <input
              id="cprTime"
              type="time"
              className={inputClass}
              value={form.cprStartTime}
              onChange={(e) => set('cprStartTime', e.target.value)}
            />
          </Field>
        )}
        <Field label={t.notes} htmlFor="notes">
          <textarea
            id="notes"
            rows={3}
            maxLength={500}
            className={cn(inputClass, 'py-3')}
            value={form.notes}
            onChange={(e) => set('notes', e.target.value)}
          />
        </Field>
      </fieldset>

      {error && (
        <p role="alert" className="rounded-xl bg-primary/15 px-4 py-3 text-lg font-bold text-primary">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={saving}
        className="flex min-h-16 items-center justify-center gap-3 rounded-2xl bg-primary text-xl font-bold text-primary-foreground disabled:opacity-60"
      >
        <Save className="size-6" aria-hidden />
        {saving ? t.saving : t.save}
      </button>
    </form>
  )
}

function Field({ label, htmlFor, children }: { label: string; htmlFor: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={htmlFor} className="text-base font-semibold">
        {label}
      </label>
      {children}
    </div>
  )
}

function Segmented({
  value,
  options,
  onChange,
  labelledBy,
}: {
  value: string
  options: { value: string; label: string }[]
  onChange: (v: string) => void
  labelledBy: string
}) {
  return (
    <div role="radiogroup" aria-labelledby={labelledBy} className="grid grid-flow-col auto-cols-fr gap-2">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            'min-h-14 rounded-xl border-2 px-2 text-base font-bold',
            value === o.value ? 'border-foreground bg-foreground text-background' : 'border-border bg-background',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

function YesNo({
  id,
  label,
  value,
  onChange,
}: {
  id: string
  label: string
  value: boolean | null
  onChange: (v: boolean) => void
}) {
  const { t } = useApp()
  return (
    <div>
      <span id={`${id}-label`} className="mb-2 block text-base font-semibold">
        {label}
      </span>
      <Segmented
        labelledBy={`${id}-label`}
        value={value === null ? '' : value ? 'yes' : 'no'}
        options={[
          { value: 'yes', label: t.yes },
          { value: 'no', label: t.no },
        ]}
        onChange={(v) => onChange(v === 'yes')}
      />
    </div>
  )
}
