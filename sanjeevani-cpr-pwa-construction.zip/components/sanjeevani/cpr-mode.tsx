'use client'

import { useEffect, useRef, useState } from 'react'
import { Pause, Play, RotateCcw, Volume2, VolumeX, Mic, MicOff, Users } from 'lucide-react'
import { useApp } from './app-context'
import { useMetronome } from '@/hooks/use-metronome'
import { speak } from '@/lib/audio'
import { cn } from '@/lib/utils'
import { PulseCircle } from './pulse-circle'
import { CycleTracker } from './cycle-tracker'
import { BreathPanel } from './breath-panel'
import { DepthGuide } from './depth-guide'
import { VoicePrompts, type PromptKey } from './voice-prompts'

const BPM = 110
const CYCLE = 30
const BREATH_SECONDS = 8
const SWITCH_EVERY_MS = 120_000
const SWITCH_BANNER_MS = 10_000

type Mode = '30:2' | 'continuous'
type Phase = 'idle' | 'compress' | 'breaths' | 'paused'

function nowHHMM() {
  const d = new Date()
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

function formatElapsed(ms: number) {
  const s = Math.floor(ms / 1000)
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`
}

export function CprMode() {
  const { t, lang, session, updateSession } = useApp()
  const [mode, setMode] = useState<Mode>('30:2')
  const [phase, setPhase] = useState<Phase>('idle')
  const [soundOn, setSoundOn] = useState(true)
  const [voiceOn, setVoiceOn] = useState(true)
  const [cycleCount, setCycleCount] = useState(0)
  const [total, setTotal] = useState(0)
  const [rounds, setRounds] = useState(0)
  const [beatKey, setBeatKey] = useState(0)
  const [elapsed, setElapsed] = useState(0)
  const [breathLeft, setBreathLeft] = useState(BREATH_SECONDS)
  const [caption, setCaption] = useState<PromptKey | null>(null)

  const countRef = useRef(0)
  const modeRef = useRef(mode)
  const voiceRef = useRef(voiceOn)
  const langRef = useRef(lang)
  const tRef = useRef(t)
  modeRef.current = mode
  voiceRef.current = voiceOn
  langRef.current = lang
  tRef.current = t

  const announce = (key: PromptKey, force = false) => {
    setCaption(key)
    if (voiceRef.current || force) speak(tRef.current[key], langRef.current)
  }

  const metronome = useMetronome({
    bpm: BPM,
    soundOn,
    onBeat: () => {
      countRef.current += 1
      const n = countRef.current
      setBeatKey((k) => k + 1)
      setTotal((x) => x + 1)
      setCycleCount(n)

      if (n === 1) announce('promptHard')
      else if (n === 15) announce('promptRecoil')
      else if (modeRef.current === 'continuous' && n % 60 === 30) announce('promptDontStop')

      if (modeRef.current === '30:2' && n >= CYCLE) {
        metronome.stop()
        countRef.current = 0
        setRounds((r) => r + 1)
        setBreathLeft(BREATH_SECONDS)
        setPhase('breaths')
        setCaption(null)
        if (voiceRef.current) speak(tRef.current.giveBreaths, langRef.current)
      } else if (modeRef.current === 'continuous' && n % CYCLE === 0) {
        setRounds((r) => r + 1)
      }
    },
  })

  const sessionActive = phase === 'compress' || phase === 'breaths'

  useEffect(() => {
    if (!sessionActive) return
    const id = setInterval(() => setElapsed((e) => e + 1000), 1000)
    return () => clearInterval(id)
  }, [sessionActive])

  const startMetronome = metronome.start

  useEffect(() => {
    if (phase !== 'breaths') return
    if (breathLeft <= 0) {
      setCycleCount(0)
      setPhase('compress')
      startMetronome()
      return
    }
    const id = setTimeout(() => setBreathLeft((b) => b - 1), 1000)
    return () => clearTimeout(id)
  }, [phase, breathLeft, startMetronome])

  const start = () => {
    if (!session.cprStartTime) updateSession({ cprStartTime: nowHHMM() })
    if (phase === 'breaths') setCycleCount(0)
    setPhase('compress')
    metronome.start()
  }

  const pause = () => {
    metronome.stop()
    setPhase('paused')
  }

  const reset = () => {
    metronome.stop()
    countRef.current = 0
    setPhase('idle')
    setCycleCount(0)
    setTotal(0)
    setRounds(0)
    setElapsed(0)
    setCaption(null)
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
  }

  const changeMode = (next: Mode) => {
    if (next === mode) return
    setMode(next)
    if (phase === 'breaths') {
      setCycleCount(0)
      setPhase('compress')
      metronome.start()
    }
    countRef.current = 0
    setCycleCount(0)
  }

  const showSwitch = elapsed >= SWITCH_EVERY_MS && elapsed % SWITCH_EVERY_MS < SWITCH_BANNER_MS

  return (
    <div className="flex flex-col gap-5">
      <div role="radiogroup" aria-label="CPR mode" className="grid grid-cols-2 gap-2 rounded-2xl bg-card p-1.5">
        {(['30:2', 'continuous'] as Mode[]).map((m) => (
          <button
            key={m}
            type="button"
            role="radio"
            aria-checked={mode === m}
            onClick={() => changeMode(m)}
            className={cn(
              'min-h-12 rounded-xl px-3 text-base font-semibold transition-colors',
              mode === m ? 'bg-foreground text-background' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {m === '30:2' ? t.mode30 : t.modeContinuous}
          </button>
        ))}
      </div>

      {phase === 'breaths' ? (
        <BreathPanel secondsLeft={breathLeft} onResume={start} />
      ) : (
        <PulseCircle
          beatKey={beatKey}
          active={phase === 'compress'}
          count={mode === '30:2' ? cycleCount : total}
          label={t.push}
          idleLabel={t.ready}
          bpmLabel={t.bpm}
        />
      )}

      <p aria-live="polite" className="min-h-8 text-center text-xl font-bold text-warning text-balance">
        {showSwitch ? (
          <span className="inline-flex items-center gap-2">
            <Users className="size-5" aria-hidden />
            {t.switchRescuer}
          </span>
        ) : caption && phase === 'compress' ? (
          t[caption]
        ) : null}
      </p>

      <div className="flex gap-3">
        {phase === 'compress' ? (
          <button
            type="button"
            onClick={pause}
            className="flex min-h-16 flex-1 items-center justify-center gap-3 rounded-2xl bg-foreground text-xl font-bold text-background active:scale-[0.98]"
          >
            <Pause className="size-7" aria-hidden />
            {t.pause}
          </button>
        ) : (
          <button
            type="button"
            onClick={start}
            className="flex min-h-16 flex-1 items-center justify-center gap-3 rounded-2xl bg-primary text-xl font-bold text-primary-foreground shadow-[0_0_40px_-8px] shadow-primary active:scale-[0.98]"
          >
            <Play className="size-7 fill-current" aria-hidden />
            {phase === 'breaths' ? t.resume : t.start}
          </button>
        )}
        <button
          type="button"
          onClick={reset}
          aria-label={t.reset}
          className="flex min-h-16 min-w-16 items-center justify-center rounded-2xl bg-card text-foreground active:scale-[0.98]"
        >
          <RotateCcw className="size-6" aria-hidden />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <ToggleButton
          pressed={soundOn}
          onClick={() => setSoundOn((s) => !s)}
          label={t.sound}
          icon={soundOn ? <Volume2 className="size-6" aria-hidden /> : <VolumeX className="size-6" aria-hidden />}
        />
        <ToggleButton
          pressed={voiceOn}
          onClick={() => setVoiceOn((v) => !v)}
          label={t.voice}
          icon={voiceOn ? <Mic className="size-6" aria-hidden /> : <MicOff className="size-6" aria-hidden />}
        />
      </div>

      <CycleTracker
        mode={mode}
        cycleCount={cycleCount}
        total={total}
        rounds={rounds}
        elapsed={formatElapsed(elapsed)}
        labels={{ compressions: t.compressions, cycles: t.cycles, time: t.time }}
        cycleSize={CYCLE}
      />

      <DepthGuide />

      <VoicePrompts onPlay={(key) => announce(key, true)} />
    </div>
  )
}

function ToggleButton({
  pressed,
  onClick,
  label,
  icon,
}: {
  pressed: boolean
  onClick: () => void
  label: string
  icon: React.ReactNode
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        'flex min-h-14 items-center gap-3 rounded-2xl border-2 px-4 text-left text-base font-semibold transition-colors',
        pressed ? 'border-warning bg-warning/10 text-warning' : 'border-border bg-card text-muted-foreground',
      )}
    >
      {icon}
      <span className="flex-1 leading-tight">{label}</span>
      <span
        aria-hidden
        className={cn(
          'flex h-6 w-10 items-center rounded-full p-0.5 transition-colors',
          pressed ? 'bg-warning' : 'bg-muted',
        )}
      >
        <span className={cn('size-5 rounded-full bg-background transition-transform', pressed && 'translate-x-4')} />
      </span>
    </button>
  )
}
