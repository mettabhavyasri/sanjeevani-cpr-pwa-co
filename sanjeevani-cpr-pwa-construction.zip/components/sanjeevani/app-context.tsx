'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import useSWR from 'swr'
import { dictionaries, type Dict, type Lang } from '@/lib/i18n'
import { listIncidents, putIncident, type Incident, type SymptomKey } from '@/lib/offline-store'

export type Tab = 'cpr' | 'triage' | 'record' | 'outbox'

export interface SessionInfo {
  cprStartTime?: string
  symptoms?: SymptomKey[]
  aspirinGiven?: boolean
}

interface AppContextValue {
  lang: Lang
  setLang: (lang: Lang) => void
  t: Dict
  tab: Tab
  setTab: (tab: Tab) => void
  online: boolean
  goOnline: () => void
  goOffline: () => void
  syncing: boolean
  incidents: Incident[]
  saveIncident: (incident: Incident) => Promise<void>
  session: SessionInfo
  sessionVersion: number
  updateSession: (patch: SessionInfo) => void
  clearSession: () => void
}

const AppContext = createContext<AppContextValue | null>(null)

const LANG_KEY = 'sanjeevani-cpr:lang'
const SYNC_DELAY_MS = 900

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms))

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>('en')
  const [tab, setTab] = useState<Tab>('cpr')
  const [online, setOnline] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const [session, setSession] = useState<SessionInfo>({})
  const [sessionVersion, setSessionVersion] = useState(0)
  const syncLock = useRef(false)
  const onlineRef = useRef(online)
  onlineRef.current = online

  const { data: incidents = [], mutate } = useSWR('incidents', listIncidents, {
    revalidateOnFocus: false,
  })

  useEffect(() => {
    const saved = localStorage.getItem(LANG_KEY) as Lang | null
    if (saved && saved in dictionaries) setLangState(saved)
    const handleOffline = () => setOnline(false)
    window.addEventListener('offline', handleOffline)
    return () => window.removeEventListener('offline', handleOffline)
  }, [])

  useEffect(() => {
    document.documentElement.lang = lang
  }, [lang])

  const setLang = useCallback((next: Lang) => {
    setLangState(next)
    localStorage.setItem(LANG_KEY, next)
  }, [])

  const runSync = useCallback(async () => {
    if (syncLock.current) return
    syncLock.current = true
    setSyncing(true)
    try {
      const pending = (await listIncidents()).filter((i) => i.status !== 'synced')
      for (const item of pending) {
        if (!onlineRef.current) break
        await putIncident({ ...item, status: 'syncing' })
        await mutate()
        await wait(SYNC_DELAY_MS)
        if (!onlineRef.current) {
          await putIncident({ ...item, status: 'pending' })
          await mutate()
          break
        }
        await putIncident({ ...item, status: 'synced', syncedAt: Date.now() })
        await mutate()
      }
    } finally {
      syncLock.current = false
      setSyncing(false)
    }
  }, [mutate])

  const goOnline = useCallback(() => {
    onlineRef.current = true
    setOnline(true)
    void runSync()
  }, [runSync])

  const goOffline = useCallback(() => {
    onlineRef.current = false
    setOnline(false)
  }, [])

  const saveIncident = useCallback(
    async (incident: Incident) => {
      await putIncident(incident)
      await mutate()
      if (onlineRef.current) void runSync()
    },
    [mutate, runSync],
  )

  const updateSession = useCallback((patch: SessionInfo) => {
    setSession((prev) => ({ ...prev, ...patch }))
    setSessionVersion((v) => v + 1)
  }, [])

  const clearSession = useCallback(() => setSession({}), [])

  const value = useMemo<AppContextValue>(
    () => ({
      lang,
      setLang,
      t: dictionaries[lang],
      tab,
      setTab,
      online,
      goOnline,
      goOffline,
      syncing,
      incidents,
      saveIncident,
      session,
      sessionVersion,
      updateSession,
      clearSession,
    }),
    [lang, setLang, tab, online, goOnline, goOffline, syncing, incidents, saveIncident, session, sessionVersion, updateSession, clearSession],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}
