'use client'

import { useState } from 'react'
import {
  Armchair,
  Check,
  ChevronLeft,
  ClipboardPlus,
  Droplets,
  HeartPulse,
  Pill,
  RotateCcw,
  ShieldAlert,
  Shirt,
  Smile,
  TriangleAlert,
  Zap,
} from 'lucide-react'
import { useApp } from './app-context'
import { cn } from '@/lib/utils'
import type { SymptomKey } from '@/lib/offline-store'

type Answer = boolean | null
type AspirinState = 'given' | 'skipped' | null

const QUESTIONS = [
  { key: 'q1', icon: HeartPulse, symptom: 'chest' },
  { key: 'q2', icon: Droplets, symptom: 'sweat' },
  { key: 'q3', icon: Zap, symptom: 'radiate' },
] as const

export function TriageFlow() {
  const { t, setTab, updateSession } = useApp()
  const [answers, setAnswers] = useState<Answer[]>([null, null, null])
  const [step, setStep] = useState(0)
  const [checked, setChecked] = useState<Record<string, boolean>>({})
  const [aspirin, setAspirin] = useState<AspirinState>(null)
  const [aspirinOpen, setAspirinOpen] = useState(false)

  const finished = step >= QUESTIONS.length
  const yesCount = answers.filter(Boolean).length
  const highRisk = answers[0] === true || yesCount >= 2

  const answer = (value: boolean) => {
    setAnswers((prev) => prev.map((a, i) => (i === step ? value : a)))
    setStep((s) => s + 1)
  }

  const restart = () => {
    setAnswers([null, null, null])
    setStep(0)
    setChecked({})
    setAspirin(null)
    setAspirinOpen(false)
  }

  const saveToRecord = () => {
    const symptoms: SymptomKey[] = QUESTIONS.filter((_, i) => answers[i]).map((q) => q.symptom)
    updateSession({ symptoms, aspirinGiven: aspirin === 'given' ? true : aspirin === 'skipped' ? false : undefined })
    setTab('record')
  }

  return (
    <div className="flex flex-col gap-5">
      <header>
        <h1 className="text-2xl font-black">{t.triageTitle}</h1>
        <p className="text-base text-muted-foreground">{t.triageHint}</p>
      </header>

      <button
        type="button"
        onClick={() => setTab('cpr')}
        className="flex min-h-16 items-center gap-4 rounded-2xl border-2 border-primary bg-primary/10 px-4 text-left"
      >
        <TriangleAlert className="size-8 shrink-0 text-primary" aria-hidden />
        <span className="flex-1">
          <span className="block text-base font-semibold">{t.unresponsive}</span>
          <span className="block text-lg font-black text-primary">{t.startCprNow}</span>
        </span>
      </button>

      <ol className="grid grid-cols-3 gap-2" aria-label={t.triageHint}>
        {QUESTIONS.map((q, i) => (
          <li
            key={q.key}
            className={cn(
              'h-2 rounded-full',
              answers[i] === true ? 'bg-primary' : answers[i] === false ? 'bg-foreground/60' : i === step ? 'bg-warning' : 'bg-muted',
            )}
          >
            <span className="sr-only">
              {t.question} {i + 1}: {answers[i] === null ? '—' : answers[i] ? t.yes : t.no}
            </span>
          </li>
        ))}
      </ol>

      {!finished ? (
        <QuestionCard
          index={step}
          onAnswer={answer}
          onBack={step > 0 ? () => setStep((s) => s - 1) : undefined}
        />
      ) : (
        <>
          <section
            aria-live="polite"
            className={cn(
              'rounded-2xl border-2 p-5',
              highRisk ? 'border-primary bg-primary text-primary-foreground' : 'border-warning bg-warning/10',
            )}
          >
            <h2 className={cn('text-2xl font-black text-balance', !highRisk && 'text-warning')}>
              {highRisk ? t.resultHigh : t.resultLow}
            </h2>
            <p className="mt-1 text-lg font-medium leading-snug">{highRisk ? t.resultHighHint : t.resultLowHint}</p>
            <a
              href="tel:108"
              className={cn(
                'mt-4 flex min-h-14 items-center justify-center rounded-xl text-lg font-bold',
                highRisk ? 'bg-background text-foreground' : 'bg-warning text-warning-foreground',
              )}
            >
              {t.call108}
            </a>
          </section>

          <section aria-labelledby="firstaid-title" className="rounded-2xl bg-card p-4">
            <h2 id="firstaid-title" className="mb-3 text-xl font-bold">
              {t.firstAid}
            </h2>
            <ul className="flex flex-col gap-2">
              <CheckRow icon={Shirt} label={t.fa1} checked={!!checked.fa1} onToggle={() => setChecked((c) => ({ ...c, fa1: !c.fa1 }))} />
              <CheckRow icon={Smile} label={t.fa2} checked={!!checked.fa2} onToggle={() => setChecked((c) => ({ ...c, fa2: !c.fa2 }))} />
              <li>
                <button
                  type="button"
                  aria-expanded={aspirinOpen}
                  onClick={() => setAspirinOpen((o) => !o)}
                  className={cn(
                    'flex min-h-16 w-full items-center gap-4 rounded-xl border-2 px-3 text-left',
                    aspirin === 'given' ? 'border-success bg-success/10' : aspirin === 'skipped' ? 'border-warning bg-warning/10' : 'border-border bg-background',
                  )}
                >
                  <Pill className="size-7 shrink-0 text-warning" aria-hidden />
                  <span className="flex-1">
                    <span className="block text-lg font-semibold leading-tight">{t.fa3}</span>
                    {aspirin && (
                      <span className={cn('text-base font-semibold', aspirin === 'given' ? 'text-success' : 'text-warning')}>
                        {aspirin === 'given' ? t.aspirinGiven : t.aspirinSkipped}
                      </span>
                    )}
                  </span>
                  <ShieldAlert className="size-6 shrink-0 text-warning" aria-hidden />
                </button>
                {aspirinOpen && (
                  <div role="alertdialog" aria-label={t.fa3Safety} className="mt-2 rounded-xl border-2 border-warning bg-warning/10 p-4">
                    <p className="flex gap-3 text-lg font-semibold leading-snug">
                      <TriangleAlert className="mt-0.5 size-6 shrink-0 text-warning" aria-hidden />
                      {t.fa3Safety}
                    </p>
                    <div className="mt-3 grid grid-cols-1 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setAspirin('given')
                          setAspirinOpen(false)
                        }}
                        className="min-h-14 rounded-xl bg-success text-lg font-bold text-success-foreground"
                      >
                        {t.safeGive}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAspirin('skipped')
                          setAspirinOpen(false)
                        }}
                        className="min-h-14 rounded-xl border-2 border-warning text-lg font-bold text-warning"
                      >
                        {t.notSafe}
                      </button>
                    </div>
                  </div>
                )}
              </li>
              <CheckRow icon={Armchair} label={t.fa4} checked={!!checked.fa4} onToggle={() => setChecked((c) => ({ ...c, fa4: !c.fa4 }))} />
            </ul>
          </section>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={saveToRecord}
              className="flex min-h-16 flex-1 items-center justify-center gap-3 rounded-2xl bg-foreground text-lg font-bold text-background"
            >
              <ClipboardPlus className="size-6" aria-hidden />
              {t.saveToRecord}
            </button>
            <button
              type="button"
              onClick={restart}
              aria-label={t.restart}
              className="flex min-h-16 min-w-16 items-center justify-center rounded-2xl bg-card"
            >
              <RotateCcw className="size-6" aria-hidden />
            </button>
          </div>
        </>
      )}
    </div>
  )
}

function QuestionCard({
  index,
  onAnswer,
  onBack,
}: {
  index: number
  onAnswer: (value: boolean) => void
  onBack?: () => void
}) {
  const { t } = useApp()
  const q = QUESTIONS[index]
  const Icon = q.icon
  return (
    <section aria-live="polite" className="flex flex-col gap-5 rounded-2xl bg-card p-5">
      <div className="flex items-center justify-between">
        <span className="text-base font-semibold text-muted-foreground">
          {t.question} {index + 1} / {QUESTIONS.length}
        </span>
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            aria-label="Back"
            className="flex size-12 items-center justify-center rounded-full bg-background"
          >
            <ChevronLeft className="size-6" aria-hidden />
          </button>
        )}
      </div>
      <div className="flex flex-col items-center gap-4 text-center">
        <span className="flex size-20 items-center justify-center rounded-full bg-primary/15 text-primary">
          <Icon className="size-10" aria-hidden />
        </span>
        <h2 className="text-2xl font-black leading-tight text-balance">{t[q.key]}</h2>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => onAnswer(true)}
          className="min-h-20 rounded-2xl bg-primary text-2xl font-black text-primary-foreground active:scale-[0.98]"
        >
          {t.yes}
        </button>
        <button
          type="button"
          onClick={() => onAnswer(false)}
          className="min-h-20 rounded-2xl border-2 border-foreground/40 bg-background text-2xl font-black active:scale-[0.98]"
        >
          {t.no}
        </button>
      </div>
    </section>
  )
}

function CheckRow({
  icon: Icon,
  label,
  checked,
  onToggle,
}: {
  icon: React.ComponentType<{ className?: string; 'aria-hidden'?: boolean }>
  label: string
  checked: boolean
  onToggle: () => void
}) {
  return (
    <li>
      <button
        type="button"
        role="checkbox"
        aria-checked={checked}
        onClick={onToggle}
        className={cn(
          'flex min-h-16 w-full items-center gap-4 rounded-xl border-2 px-3 text-left transition-colors',
          checked ? 'border-success bg-success/10' : 'border-border bg-background',
        )}
      >
        <Icon className={cn('size-7 shrink-0', checked ? 'text-success' : 'text-warning')} aria-hidden />
        <span className={cn('flex-1 text-lg font-semibold leading-tight', checked && 'text-muted-foreground line-through')}>
          {label}
        </span>
        <span
          aria-hidden
          className={cn(
            'flex size-8 shrink-0 items-center justify-center rounded-lg border-2',
            checked ? 'border-success bg-success text-success-foreground' : 'border-muted-foreground',
          )}
        >
          {checked && <Check className="size-5" />}
        </span>
      </button>
    </li>
  )
}
