'use client'

import { Wind } from 'lucide-react'
import { useApp } from './app-context'

export function BreathPanel({ secondsLeft, onResume }: { secondsLeft: number; onResume: () => void }) {
  const { t } = useApp()
  return (
    <section
      aria-live="assertive"
      className="flex min-h-64 flex-col items-center justify-center gap-4 rounded-3xl border-4 border-warning bg-warning/10 p-6 text-center"
    >
      <div className="flex items-center gap-3">
        <Wind className="size-10 text-warning" aria-hidden />
        <Wind className="size-10 text-warning" aria-hidden />
      </div>
      <h2 className="text-3xl font-black text-warning text-balance">{t.giveBreaths}</h2>
      <p className="text-lg font-medium leading-snug text-foreground text-pretty">{t.breathHint}</p>
      <button
        type="button"
        onClick={onResume}
        className="mt-1 min-h-12 rounded-full bg-warning px-6 text-base font-bold text-warning-foreground"
      >
        {t.breathsLeft} {secondsLeft}s
      </button>
    </section>
  )
}
