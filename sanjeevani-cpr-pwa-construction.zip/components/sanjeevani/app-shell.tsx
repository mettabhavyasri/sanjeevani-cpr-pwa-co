'use client'

import { useEffect } from 'react'
import { AppProvider, useApp, type Tab } from './app-context'
import { EmergencyBar } from './emergency-bar'
import { BottomNav } from './bottom-nav'
import { CprMode } from './cpr-mode'
import { TriageFlow } from './triage-flow'
import { IncidentForm } from './incident-form'
import { Outbox } from './outbox'

export function AppShell() {
  return (
    <AppProvider>
      <ServiceWorkerRegistration />
      <div className="mx-auto flex min-h-dvh max-w-md flex-col">
        <EmergencyBar />
        <Screens />
        <BottomNav />
      </div>
    </AppProvider>
  )
}

function Screens() {
  const { tab } = useApp()
  // Screens stay mounted so CPR keeps running while the worker fills in a record.
  const panel = (id: Tab, node: React.ReactNode) => (
    <section hidden={tab !== id} aria-hidden={tab !== id}>
      {node}
    </section>
  )
  return (
    <main className="flex-1 px-4 pb-28 pt-5">
      {panel('cpr', <CprMode />)}
      {panel('triage', <TriageFlow />)}
      {panel('record', <IncidentForm />)}
      {panel('outbox', <Outbox />)}
    </main>
  )
}

function ServiceWorkerRegistration() {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production' || !('serviceWorker' in navigator)) return
    if (window.self !== window.top) return
    navigator.serviceWorker.register('/sw.js').catch(() => {})
  }, [])
  return null
}
