import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Noto_Sans, Noto_Sans_Devanagari, Noto_Sans_Telugu } from 'next/font/google'
import './globals.css'

const noto = Noto_Sans({ subsets: ['latin'], variable: '--font-noto', display: 'swap' })
const notoDevanagari = Noto_Sans_Devanagari({
  subsets: ['devanagari'],
  weight: ['400', '600', '700', '900'],
  variable: '--font-noto-devanagari',
  display: 'swap',
})
const notoTelugu = Noto_Sans_Telugu({
  subsets: ['telugu'],
  weight: ['400', '600', '700', '900'],
  variable: '--font-noto-telugu',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Sanjeevani CPR - Rural Cardiac Emergency Assistant',
  description:
    'Offline-first CPR metronome, heart attack check and patient incident log for ASHA workers and bystanders. Works with zero internet in English, Hindi, Telugu and Marathi.',
  generator: 'v0.app',
  applicationName: 'Sanjeevani CPR',
  manifest: '/manifest.webmanifest',
  appleWebApp: { capable: true, title: 'Sanjeevani CPR', statusBarStyle: 'black-translucent' },
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#141012',
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${noto.variable} ${notoDevanagari.variable} ${notoTelugu.variable} bg-background`}>
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
