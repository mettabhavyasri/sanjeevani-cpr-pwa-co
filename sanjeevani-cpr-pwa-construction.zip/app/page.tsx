import { AppShell } from '@/components/sanjeevani/app-shell'

export default function Page() {
  return <AppShell />
}
