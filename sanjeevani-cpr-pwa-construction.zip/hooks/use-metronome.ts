'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { playClick } from '@/lib/audio'

const LOOKAHEAD_S = 0.1
const SCHEDULER_MS = 25

interface Options {
  bpm: number
  soundOn: boolean
  onBeat: () => void
}

/**
 * Sample-accurate metronome: clicks are scheduled ahead on the Web Audio clock,
 * and the visual beat callback fires from rAF when each scheduled time arrives.
 */
export function useMetronome({ bpm, soundOn, onBeat }: Options) {
  const [running, setRunning] = useState(false)
  const ctxRef = useRef<AudioContext | null>(null)
  const nextTimeRef = useRef(0)
  const queueRef = useRef<number[]>([])
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const rafRef = useRef<number | null>(null)
  const soundRef = useRef(soundOn)
  const onBeatRef = useRef(onBeat)
  const bpmRef = useRef(bpm)

  soundRef.current = soundOn
  onBeatRef.current = onBeat
  bpmRef.current = bpm

  const stop = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current)
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    timerRef.current = null
    rafRef.current = null
    queueRef.current = []
    setRunning(false)
  }, [])

  const start = useCallback(() => {
    if (timerRef.current) return
    if (!ctxRef.current) {
      const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      ctxRef.current = new Ctor()
    }
    const ctx = ctxRef.current
    void ctx.resume()
    nextTimeRef.current = ctx.currentTime + 0.05

    const schedule = () => {
      while (nextTimeRef.current < ctx.currentTime + LOOKAHEAD_S) {
        if (soundRef.current) playClick(ctx, nextTimeRef.current)
        queueRef.current.push(nextTimeRef.current)
        nextTimeRef.current += 60 / bpmRef.current
      }
    }

    const tick = () => {
      while (queueRef.current.length && queueRef.current[0] <= ctx.currentTime) {
        queueRef.current.shift()
        onBeatRef.current()
        if (!timerRef.current) return
      }
      rafRef.current = requestAnimationFrame(tick)
    }

    schedule()
    timerRef.current = setInterval(schedule, SCHEDULER_MS)
    rafRef.current = requestAnimationFrame(tick)
    setRunning(true)
  }, [])

  useEffect(() => () => {
    stop()
    void ctxRef.current?.close()
  }, [stop])

  return { running, start, stop }
}
