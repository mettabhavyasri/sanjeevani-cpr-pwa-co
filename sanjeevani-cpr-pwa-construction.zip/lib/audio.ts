import { speechLang, type Lang } from './i18n'

export function speak(text: string, lang: Lang) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false
  const synth = window.speechSynthesis
  synth.cancel()
  const utterance = new SpeechSynthesisUtterance(text)
  const code = speechLang(lang)
  utterance.lang = code
  const voice = synth.getVoices().find((v) => v.lang.toLowerCase().startsWith(code.slice(0, 2)))
  if (voice) utterance.voice = voice
  utterance.rate = 1
  synth.speak(utterance)
  return true
}

export function playClick(ctx: AudioContext, time: number, accent = false) {
  const osc = ctx.createOscillator()
  const gain = ctx.createGain()
  osc.type = 'square'
  osc.frequency.value = accent ? 1320 : 880
  gain.gain.setValueAtTime(0.0001, time)
  gain.gain.exponentialRampToValueAtTime(0.35, time + 0.004)
  gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.06)
  osc.connect(gain).connect(ctx.destination)
  osc.start(time)
  osc.stop(time + 0.07)
}
