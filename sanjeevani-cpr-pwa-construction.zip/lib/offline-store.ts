export type SyncStatus = 'pending' | 'syncing' | 'synced'

export type Sex = 'male' | 'female' | 'other'

export type SymptomKey = 'chest' | 'sweat' | 'radiate' | 'breath' | 'unconscious'

export interface Incident {
  id: string
  name: string
  age: number
  sex: Sex
  onsetTime: string
  symptoms: SymptomKey[]
  aspirinGiven: boolean
  cprStarted: boolean
  cprStartTime: string
  notes: string
  createdAt: number
  status: SyncStatus
  syncedAt?: number
}

const DB_NAME = 'sanjeevani-cpr'
const STORE = 'incidents'
const FALLBACK_KEY = 'sanjeevani-cpr:incidents'

let dbPromise: Promise<IDBDatabase> | null = null

function hasIndexedDB() {
  return typeof window !== 'undefined' && 'indexedDB' in window
}

function openDB(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1)
      request.onupgradeneeded = () => {
        const db = request.result
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: 'id' })
        }
      }
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => {
        dbPromise = null
        reject(request.error)
      }
    })
  }
  return dbPromise
}

function readFallback(): Incident[] {
  try {
    return JSON.parse(localStorage.getItem(FALLBACK_KEY) ?? '[]') as Incident[]
  } catch {
    return []
  }
}

function writeFallback(items: Incident[]) {
  localStorage.setItem(FALLBACK_KEY, JSON.stringify(items))
}

export async function listIncidents(): Promise<Incident[]> {
  let items: Incident[]
  if (hasIndexedDB()) {
    try {
      const db = await openDB()
      items = await new Promise<Incident[]>((resolve, reject) => {
        const req = db.transaction(STORE, 'readonly').objectStore(STORE).getAll()
        req.onsuccess = () => resolve(req.result as Incident[])
        req.onerror = () => reject(req.error)
      })
    } catch {
      items = readFallback()
    }
  } else {
    items = readFallback()
  }
  return items.sort((a, b) => b.createdAt - a.createdAt)
}

export async function putIncident(incident: Incident): Promise<void> {
  if (hasIndexedDB()) {
    try {
      const db = await openDB()
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(STORE, 'readwrite')
        tx.objectStore(STORE).put(incident)
        tx.oncomplete = () => resolve()
        tx.onerror = () => reject(tx.error)
      })
      return
    } catch {
      // IndexedDB can be blocked in private modes; localStorage keeps the record safe.
    }
  }
  const items = readFallback().filter((i) => i.id !== incident.id)
  writeFallback([...items, incident])
}

export function createId() {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`
}
